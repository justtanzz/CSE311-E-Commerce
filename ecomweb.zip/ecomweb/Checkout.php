<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        .container {
            width: 80%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        table {
            width: 100%;
            background-color: #fff;
            border-collapse: collapse;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .place-order-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .place-order-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Order Details</h1>
        <table>
            <tr>
                <th>Order Number</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Total Price</th>
            </tr>
            <?php
            session_start();
            include("connection.php");
            mysqli_select_db($conn, 'ecommerce');

            $customerID = $_SESSION['cid']; // Get customer ID from session

            // Retrieve cart items for the customer
            $cartItemsQuery = "SELECT * FROM Cart WHERE CustomerID = '{$customerID}'";
            $cartItemsResult = $conn->query($cartItemsQuery);

            // Initialize order number and total price variables
            $orderNumber = uniqid('order_');
            $totalPrice = 0;

            while ($cartItem = mysqli_fetch_assoc($cartItemsResult)) {
                // Display existing items in the cart and calculate total price
                $productName = $cartItem['PID']; // Assuming PID represents the product name in the Cart table
                $quantity = $cartItem['Quantity'];
                $itemTotalPrice = $cartItem['TotalPrice'];
                $totalPrice += $itemTotalPrice;

                echo "<tr>";
                echo "<td>{$orderNumber}</td>";
                echo "<td>{$productName}</td>";
                echo "<td>{$quantity}</td>";
                echo "<td>{$itemTotalPrice}</td>";
                echo "</tr>";
            }

            // Insert order details into the Order table
            $insertOrderQuery = "INSERT INTO `Order` (OrderNo, OrderedProductID, No_Of_Items, OrderedPname, TotalPrice, Shipping_Status)
                                VALUES ('$orderNumber', '{$productName}', '$quantity', '{$productName}', '$totalPrice', 'Pending')";

            // Execute the insertion query
            mysqli_query($conn, $insertOrderQuery);
            ?>
        </table>
        <a href="home.php" class="place-order-btn">Place Order</a>
    </div>
</body>

</html>
