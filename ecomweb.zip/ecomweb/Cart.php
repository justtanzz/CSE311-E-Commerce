<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
<style>
    body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        .container {
            width: 80%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        table {
            width: 100%;
            background-color: #fff;
            border-collapse: collapse;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .update-btn,
        .remove-btn,
        .go-back-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            cursor: pointer;
            margin-right: 10px;
            transition: background-color 0.3s ease;
        }

        .update-btn:hover,
        .remove-btn:hover,
        .go-back-btn:hover {
            background-color: #45a049;
        }
        .checkout-btn {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .checkout-btn:hover {
            background-color: #45a049;
        }
        
    </style>
</head>

<body>
    <div class="container">
        <h1>Shopping Cart</h1>
        <table>
            <tr>
                <th>CartID</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Action</th>
            </tr>
            <?php
            session_start();
            include("connection.php");
            mysqli_select_db($conn, 'ecommerce');

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (isset($_POST['update'])) {
                    // Handle update logic here
                    $newQuantity = $_POST['quantity']; // Get updated quantity from the form
                    $cartID = $_POST['cart_id']; // Get CartID from the form

                    // Update Quantity and TotalPrice in the Cart table
                    $updateQuery = "UPDATE Cart SET Quantity = '$newQuantity', TotalPrice = Price * '$newQuantity' WHERE CartID = '$cartID'";
                    mysqli_query($conn, $updateQuery);
                } elseif (isset($_POST['remove'])) {
                    // Handle remove logic here
                    $cartID = $_POST['cart_id']; // Get CartID from the form

                    // Delete the item from the Cart table
                    $deleteQuery = "DELETE FROM Cart WHERE CartID = '$cartID'";
                    mysqli_query($conn, $deleteQuery);
                }
            }

            $customerID = $_SESSION['cid'];
            $cartItemsQuery = "SELECT * FROM Cart WHERE CustomerID = '{$customerID}'";
            $cartItemsResult = $conn->query($cartItemsQuery);

            while ($cartItem = mysqli_fetch_assoc($cartItemsResult)) {
                echo "<tr>";
                echo "<td>{$cartItem['CartID']}</td>";
                echo "<td>{$cartItem['Price']}</td>";
                echo "<td>{$cartItem['Quantity']}</td>";
                echo "<td>{$cartItem['TotalPrice']}</td>";
                echo "<td>
                        <form method='post' action=''>
                            <input type='hidden' name='cart_id' value='{$cartItem['CartID']}'>
                            <input type='number' name='quantity' value='{$cartItem['Quantity']}' min='1' max='100'>
                            <button type='submit' name='update' class='update-btn'>Update</button>
                            <button type='submit' name='remove' class='remove-btn'>Remove</button>
                        </form>
                      </td>";
                echo "</tr>";
            }
            echo "<tr>";
            echo "<td colspan='4'></td>"; // Empty cell for alignment
            echo "<td><a href='checkout.php' class='checkout-btn'>Checkout</a></td>";
            echo "</tr>";
            ?>
        </table>
        <a href="home.php" class="go-back-btn">Go Back</a>
    </div>
</body>

</html>
